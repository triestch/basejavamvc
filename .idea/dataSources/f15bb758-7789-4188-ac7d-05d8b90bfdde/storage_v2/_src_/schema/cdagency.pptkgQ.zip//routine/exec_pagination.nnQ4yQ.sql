create procedure exec_pagination(IN `_pagecurrent` int, IN `_pagesize` int, IN `_tablename` varchar(1024),
                                 IN `_table_key`   varchar(1024), IN `_fields` varchar(1024), IN `_where` varchar(2048),
                                 IN `_order`       varchar(2048))
  BEGIN
if _pagesize<0&&_pagecurrent<1 then
        if _fields is null||_fields='' then
            set _fields='*';
        end if;
        set @strsql = concat('select ',_fields,' from ',_tablename,_where,' ',_order); 
else
        if _fields is null||_fields='' then
            set _fields='*';
        end if;
        
        set @strsql = concat('select ',_fields,' from ',_tablename,_where,'  ',_order,'  limit ',_pagecurrent*_pagesize-_pagesize,',',_pagesize); 
    end if;
    
     
    
    prepare stmtsql from @strsql; 
    execute stmtsql; 
    deallocate prepare stmtsql;
    set @strsqlcount=concat('select count(',_table_key,') as count from ',_tablename,_where);/*count(1) 这个字段最好是主键*/
    prepare stmtsqlcount from @strsqlcount; 
    execute stmtsqlcount; 
    deallocate prepare stmtsqlcount;
END;

