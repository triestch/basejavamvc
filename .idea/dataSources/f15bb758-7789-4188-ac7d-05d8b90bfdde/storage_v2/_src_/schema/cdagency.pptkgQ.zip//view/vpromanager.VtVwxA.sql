create view vpromanager as
  select
    `cdagency`.`zfcg_pjt_managers`.`pkid`                     AS `pkid`,
    `cdagency`.`zfcg_pjt_managers`.`unified_deal_code`        AS `unified_deal_code`,
    `cdagency`.`zfcg_pjt_managers`.`proid`                    AS `proid`,
    `cdagency`.`zfcg_pjt_managers`.`deptid`                   AS `deptid`,
    `cdagency`.`zfcg_pjt_managers`.`deptname`                 AS `deptname`,
    `cdagency`.`zfcg_pjt_managers`.`dealtype`                 AS `dealtype`,
    `cdagency`.`zfcg_pjt_managers`.`dealuserid`               AS `dealuserid`,
    `cdagency`.`zfcg_pjt_managers`.`dealusername`             AS `dealusername`,
    `cdagency`.`zfcg_pjt_managers`.`iscurrent`                AS `iscurrent`,
    `cdagency`.`zfcg_pjt_managers`.`createrid`                AS `createrid`,
    `cdagency`.`zfcg_pjt_managers`.`creatername`              AS `creatername`,
    `cdagency`.`zfcg_pjt_managers`.`createtime`               AS `createtime`,
    `cdagency`.`zfcg_pjt_managers`.`updaterid`                AS `updaterid`,
    `cdagency`.`zfcg_pjt_managers`.`updatername`              AS `updatername`,
    `cdagency`.`zfcg_pjt_managers`.`updatetime`               AS `updatetime`,
    `cdagency`.`zfcg_pjt_managers`.`isdel`                    AS `isdel`,
    `cdagency`.`zfcg_pjt_managers`.`delerid`                  AS `delerid`,
    `cdagency`.`zfcg_pjt_managers`.`delername`                AS `delername`,
    `cdagency`.`zfcg_pjt_managers`.`deltime`                  AS `deltime`,
    `cdagency`.`zfcg_pjt_projectinfo`.`purchase_project_code` AS `purchase_project_code`,
    `cdagency`.`zfcg_pjt_projectinfo`.`purchase_project_name` AS `purchase_project_name`,
    `cdagency`.`zfcg_pjt_projectinfo`.`nodeflowname`          AS `nodeflowname`
  from (`cdagency`.`zfcg_pjt_projectinfo`
    join `cdagency`.`zfcg_pjt_managers`
      on ((`cdagency`.`zfcg_pjt_projectinfo`.`pkid` = `cdagency`.`zfcg_pjt_managers`.`proid`)));

