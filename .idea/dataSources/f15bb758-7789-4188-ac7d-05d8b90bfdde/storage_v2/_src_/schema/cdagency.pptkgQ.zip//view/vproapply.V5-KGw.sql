create view vproapply as
  select
    `cdagency`.`zfcg_pjt_apply`.`pkid`                        AS `pkid`,
    `cdagency`.`zfcg_pjt_apply`.`unified_deal_code`           AS `unified_deal_code`,
    `cdagency`.`zfcg_pjt_apply`.`proid`                       AS `proid`,
    `cdagency`.`zfcg_pjt_apply`.`noticeid`                    AS `noticeid`,
    `cdagency`.`zfcg_pjt_apply`.`serialnum`                   AS `serialnum`,
    `cdagency`.`zfcg_pjt_apply`.`isunion`                     AS `isunion`,
    `cdagency`.`zfcg_pjt_apply`.`unionflag`                   AS `unionflag`,
    `cdagency`.`zfcg_pjt_apply`.`companyid`                   AS `companyid`,
    `cdagency`.`zfcg_pjt_apply`.`companycode`                 AS `companycode`,
    `cdagency`.`zfcg_pjt_apply`.`companyname`                 AS `companyname`,
    `cdagency`.`zfcg_pjt_apply`.`legalperson`                 AS `legalperson`,
    `cdagency`.`zfcg_pjt_apply`.`companyaddress`              AS `companyaddress`,
    `cdagency`.`zfcg_pjt_apply`.`contactper`                  AS `contactper`,
    `cdagency`.`zfcg_pjt_apply`.`contactpertel`               AS `contactpertel`,
    `cdagency`.`zfcg_pjt_apply`.`contactperphone`             AS `contactperphone`,
    `cdagency`.`zfcg_pjt_apply`.`contactperfax`               AS `contactperfax`,
    `cdagency`.`zfcg_pjt_apply`.`contactperemail`             AS `contactperemail`,
    `cdagency`.`zfcg_pjt_apply`.`remark`                      AS `remark`,
    `cdagency`.`zfcg_pjt_apply`.`createrid`                   AS `createrid`,
    `cdagency`.`zfcg_pjt_apply`.`creatername`                 AS `creatername`,
    `cdagency`.`zfcg_pjt_apply`.`createtime`                  AS `createtime`,
    `cdagency`.`zfcg_pjt_apply`.`updaterid`                   AS `updaterid`,
    `cdagency`.`zfcg_pjt_apply`.`updatername`                 AS `updatername`,
    `cdagency`.`zfcg_pjt_apply`.`updatetime`                  AS `updatetime`,
    `cdagency`.`zfcg_pjt_apply`.`isdel`                       AS `isdel`,
    `cdagency`.`zfcg_pjt_apply`.`delerid`                     AS `delerid`,
    `cdagency`.`zfcg_pjt_apply`.`delername`                   AS `delername`,
    `cdagency`.`zfcg_pjt_apply`.`deltime`                     AS `deltime`,
    `cdagency`.`zfcg_pjt_projectinfo`.`purchase_project_code` AS `purchase_project_code`,
    `cdagency`.`zfcg_pjt_projectinfo`.`purchase_project_name` AS `purchase_project_name`
  from (`cdagency`.`zfcg_pjt_apply`
    join `cdagency`.`zfcg_pjt_projectinfo`
      on ((`cdagency`.`zfcg_pjt_apply`.`unified_deal_code` = `cdagency`.`zfcg_pjt_projectinfo`.`unified_deal_code`)));

